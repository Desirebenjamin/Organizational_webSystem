<?php

require_once"connection.php";

if(ISSET($_POST['signup'])){

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password_1'];
$cpass = $_POST['password_2'];

if($password == $cpass){
	$sql = "INSERT INTO users_tbl(Username, Email, password, c_password) VALUES('$username', '$email', '$password', '$cpass')";

if(mysqli_query($conn, $sql)){

echo "Account created you can login";
header("refresh:5;index.html");

}
else{
	echo "Sorry the Account was not created try again";
	header("refresh:5;register.html");


}


}
else{

	echo "The passwords do not match please confirm the right password";
	header("refresh:5;register.html");
}






         } ?>

