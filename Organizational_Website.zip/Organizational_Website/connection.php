<?php

$conn = mysqli_connect("localhost","root","","clients_db");

if($conn){
	echo "";

}
else{
	echo "Connection Failed".mysqli_connect_errno();
}



      ?>
