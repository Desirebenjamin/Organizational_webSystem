<?php

require_once 'connection.php';

if(ISSET($_POST['login'])){

$username = $_POST['username'];
$password = $_POST['password_1'];

$query = "SELECT * FROM users_tbl WHERE Username = '$username' AND Password = '$password'";

$result = mysqli_query($conn, $query);

if($row = mysqli_fetch_array($result)){

session_start();
$_SESSION['id'] = $row['id'];
$_SESSION['Usernname'] = $row['Username'];

$id = $row['id'];
$user = $row['Username'];

if($username== $user){

	
	?>
	   <script type="text/javascript">
	   	window.alert("Login Successfull");
	   	window.location.href = "index.html";
	   </script>



	<?php




}


}
else{

	echo "Your password or username is wrong try again";
	header("refresh:5;register.html");
}










}





         

         ?>